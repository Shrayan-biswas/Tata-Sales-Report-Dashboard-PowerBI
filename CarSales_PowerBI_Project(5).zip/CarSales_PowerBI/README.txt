HOW TO OPEN
1. Unzip this folder anywhere.
2. In Power BI Desktop: File > Options > Preview features > enable "Power BI Project (.pbip) save option" and "Store semantic model using TMDL format" (and "Store reports using enhanced metadata format (PBIR)" if listed). Restart Desktop.
3. File > Open report > Browse this device > pick CarSales.pbip.
4. When it asks (or via Home > Transform data > Edit parameters), set ExcelFilePath to the full path of car_sale_final-4_1_.xlsx
   (a copy is included in this folder). Click Refresh.
